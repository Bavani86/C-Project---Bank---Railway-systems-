# C-Project-Banking-Railway
A C-based project implementing a Bank Management System and Railway Reservation System using structures. Designed to manage banking transactions and facilitate train ticket booking in a single, integrated application.
